# Kulit Kedelai > Soybean
https://universe.roboflow.com/gpts-workspace-c64zv/kulit-kedelai

Provided by a Roboflow user
License: CC BY 4.0

